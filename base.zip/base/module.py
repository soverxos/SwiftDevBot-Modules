import logging
from typing import List, Dict, Any

from aiogram import Router
from aiogram.types import BotCommand

from core.module_interface import ModuleInterface
from modules.base.handlers import setup_handlers


class BaseModule(ModuleInterface):
    """Базовый модуль бота с примером функциональности."""
    
    def __init__(self, name: str, core: Any):
        super().__init__(name, core)
        self.logger = logging.getLogger(f"Module.{name}")
        self.router = Router(name=f"{name}_router")
        
        # Регистрация обработчиков
        setup_handlers(self.router, core)
        
        # Регистрация подписок на события
        self._register_event_handlers()
        
        self.logger.info(f"Модуль {name} инициализирован")
        
    def get_routers(self) -> List[Router]:
        """Возвращает список роутеров модуля."""
        return [self.router]
    
    async def get_commands(self) -> List[BotCommand]:
        """Возвращает список команд модуля."""
        return [
            BotCommand(command="about", description="О боте"),
            BotCommand(command="ping", description="Проверка работоспособности бота"),
            BotCommand(command="stats", description="Статистика использования бота")
        ]
    
    async def get_menu_items(self) -> List[Dict[str, Any]]:
        """Возвращает элементы для меню модуля."""
        return [
            {
                "text": "О боте",
                "callback_data": "base:about",
                "icon": "ℹ️",
                "order": 10
            },
            {
                "text": "Статистика",
                "callback_data": "base:stats",
                "icon": "📊",
                "order": 20
            }
        ]
    
    async def shutdown(self) -> None:
        """Выполняется при выключении модуля."""
        self.logger.info(f"Модуль {self.name} выключается")
        
        # Отписка от событий
        # TODO: Реализовать отписку от всех событий при выгрузке модуля
        
    def _register_event_handlers(self) -> None:
        """Регистрирует обработчики событий."""
        self.core.event_bus.subscribe(
            "user:registered", 
            self.on_module_event
        )
        
    async def on_module_event(self, data: Dict[str, Any]) -> None:
        """Обработчик событий от других модулей через Event Bus."""
        event_type = data.get('event_type', '')
        
        if event_type == "user:registered":
            user_id = data.get("user_id")
            username = data.get("username", "")
            first_name = data.get("first_name", "")
            
            self.logger.info(f"Получено событие о новом пользователе: {user_id} ({username or first_name})")


async def setup(core) -> BaseModule:
    """
    Инициализация и настройка модуля.
    
    :param core: Ядро бота
    :return: Экземпляр модуля
    """
    return BaseModule("base", core)

import logging
import time
import platform

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder


logger = logging.getLogger(__name__)


def setup_handlers(router: Router, core):
    """
    Настраивает обработчики команд и колбэков модуля.
    
    :param router: Роутер модуля
    :param core: Ядро бота
    """
    # Команда /about
    @router.message(Command("about"))
    async def about_command(message: Message):
        await show_about(message.from_user.id, core, message_obj=message)
    
    # Команда /ping
    @router.message(Command("ping"))
    async def ping_command(message: Message):
        # Измеряем время ответа
        start_time = time.time()
        
        # Отправляем первичное сообщение
        sent_message = await message.answer("🏓 Проверка...")
        
        # Вычисляем задержку
        response_time = round((time.time() - start_time) * 1000)  # в миллисекундах
        
        # Обновляем сообщение с информацией о задержке
        await sent_message.edit_text(f"🏓 Понг! Задержка: {response_time} мс")
        
        # Записываем статистику использования
        await record_command_usage(core, "ping")
    
    # Команда /stats
    @router.message(Command("stats"))
    async def stats_command(message: Message):
        await show_stats(message.from_user.id, core, message_obj=message)
    
    # Обработчик колбэков
    @router.callback_query(F.data.startswith("base:"))
    async def base_callback(callback: CallbackQuery):
        action = callback.data.split(":", 1)[1]
        
        if action == "about":
            await show_about(callback.from_user.id, core, callback_obj=callback)
        elif action == "stats":
            await show_stats(callback.from_user.id, core, callback_obj=callback)
        else:
            await callback.answer("Неизвестное действие")


async def show_about(user_id: int, core, message_obj=None, callback_obj=None):
    """Показывает информацию о боте."""
    # Собираем информацию о боте
    bot_info = await core.bot.get_me()
    
    text = (
        f"ℹ️ <b>{bot_info.full_name}</b>\n\n"
        "SwiftDevBot - модульный Telegram-бот с гибкой архитектурой.\n\n"
        f"<b>Версия:</b> {core.config.environment.upper()}\n"
        f"<b>Автор:</b> SoverX\n"
        f"<b>Загружено модулей:</b> {len(core.module_manager.modules)}\n\n"
        "<b>Технологии:</b>\n"
        f"• Python {platform.python_version()}\n"
        "• Aiogram 3.19+\n"
        f"• БД: {core.config.database.type}\n"
        f"• FSM хранилище: {core.config.fsm_storage.type}\n\n"
        "Для получения дополнительной информации используйте команду /help."
    )
    
    # Создаем клавиатуру с кнопкой возврата в меню
    keyboard = InlineKeyboardBuilder()
    keyboard.button(text="◀️ Назад в меню", callback_data="menu:main")
    
    # Отправляем сообщение или обновляем существующее
    if callback_obj:
        await callback_obj.message.edit_text(text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
        await callback_obj.answer()
    else:
        await core.bot.send_message(user_id, text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
    
    # Записываем статистику использования
    await record_command_usage(core, "about")


async def show_stats(user_id: int, core, message_obj=None, callback_obj=None):
    """Показывает статистику использования бота."""
    # Собираем статистику из БД
    try:
        stats_data = await core.db_manager.fetch_all(
            "SELECT module, event, count FROM stats ORDER BY count DESC LIMIT 10"
        )
        
        users_count = await core.db_manager.fetch_one(
            "SELECT COUNT(*) as count FROM users"
        )
        
        chats_count = await core.db_manager.fetch_one(
            "SELECT COUNT(*) as count FROM chats"
        )
        
        active_sessions = len(core.session_manager.sessions)
        
        text = (
            "📊 <b>Статистика бота</b>\n\n"
            f"<b>Пользователей:</b> {users_count['count'] if users_count else 0}\n"
            f"<b>Групповых чатов:</b> {chats_count['count'] if chats_count else 0}\n"
            f"<b>Активных сессий:</b> {active_sessions}\n"
            f"<b>Загружено модулей:</b> {len(core.module_manager.modules)}\n\n"
        )
        
        if stats_data:
            text += "<b>Популярные команды:</b>\n"
            for stat in stats_data:
                text += f"• {stat['module']}:{stat['event']} - {stat['count']} раз\n"
        else:
            text += "Статистика команд пока отсутствует."
        
        # Создаем клавиатуру с кнопкой возврата в меню
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="🔄 Обновить", callback_data="base:stats")
        keyboard.button(text="◀️ Назад в меню", callback_data="menu:main")
        
        # Отправляем сообщение или обновляем существующее
        if callback_obj:
            await callback_obj.message.edit_text(text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
            await callback_obj.answer()
        else:
            await core.bot.send_message(user_id, text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
        
    except Exception as e:
        logger.error(f"Ошибка при получении статистики: {e}")
        
        text = "⚠️ Не удалось загрузить статистику бота."
        
        # Создаем клавиатуру с кнопкой возврата в меню
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="◀️ Назад в меню", callback_data="menu:main")
        
        # Отправляем сообщение или обновляем существующее
        if callback_obj:
            await callback_obj.message.edit_text(text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
            await callback_obj.answer()
        else:
            await core.bot.send_message(user_id, text, reply_markup=keyboard.as_markup(), parse_mode="HTML")
    
    # Записываем использование команды статистики
    await record_command_usage(core, "stats")


async def record_command_usage(core, command_name: str):
    """
    Записывает использование команды в статистику.
    
    :param core: Ядро бота
    :param command_name: Имя команды
    """
    try:
        # Проверяем, есть ли запись для этой команды
        existing = await core.db_manager.fetch_one(
            "SELECT id, count FROM stats WHERE module = ? AND event = ?",
            ("base", command_name)
        )
        
        if existing:
            # Обновляем счетчик
            await core.db_manager.execute(
                "UPDATE stats SET count = count + 1, last_updated = CURRENT_TIMESTAMP WHERE id = ?",
                (existing["id"],)
            )
        else:
            # Создаем новую запись
            await core.db_manager.execute(
                "INSERT INTO stats (module, event, count) VALUES (?, ?, 1)",
                ("base", command_name)
            )
    except Exception as e:
        logger.error(f"Ошибка при записи статистики: {e}")

# modules/my_module/models.py
models = [
    {
        "name": "users",
        "fields": [
            {"name": "id", "type": "SERIAL PRIMARY KEY"},
            {"name": "username", "type": "VARCHAR(64) NOT NULL UNIQUE"},
            {"name": "full_name", "type": "VARCHAR(128)"},
            {"name": "is_admin", "type": "BOOLEAN DEFAULT FALSE"},
            {"name": "created_at", "type": "TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW()"}
        ]
    }
]